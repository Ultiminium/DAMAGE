from .interpreter import Interpreter

def run(source: str):
    Interpreter().run(source)
