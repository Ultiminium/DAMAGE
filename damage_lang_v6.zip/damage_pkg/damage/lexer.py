import re
from dataclasses import dataclass
from typing import List

# ── Token Types ────────────────────────────────────────────
FUNC_OPEN    = "FUNC_OPEN"    # @print+  or  @print,math+
FUNC_CLOSE   = "FUNC_CLOSE"   # @-
CONTENT      = "CONTENT"      # +hello world-
VAR_DECL     = "VAR_DECL"     # score+5-  (inside @var block)
VAR_CREATE   = "VAR_CREATE"   # @var:create+name-
LOOP_COUNT   = "LOOP_COUNT"   # @loop:5
IF_COND      = "IF_COND"      # if, score=5
MATH_EXPR    = "MATH_EXPR"    # 1+1  (inside standalone @math block)
INLINE_CALL  = "INLINE_CALL"  # @+content-  or  @(())+content-
ADDFUNC_OPEN = "ADDFUNC_OPEN" # @addfunc+
ADDFUNC_NAME = "ADDFUNC_NAME" # @addfunc:createname"name"
ADDFUNC_CLOSE= "ADDFUNC_CLOSE"# @---
GUI_OPEN     = "GUI_OPEN"     # @gui,print+  or @gui+
GUI_PROP     = "GUI_PROP"     # @gui:winname"x" @gui:winsize"x" @gui:text etc
GUI_WRITE    = "GUI_WRITE"    # @gui:n+content-  (write to element)
OUTPUT_NAME  = "OUTPUT_NAME"  # @output:createname"file.txt"
DYN_ASSIGN   = "DYN_ASSIGN"   # @dyn:(var) = value
OTHER_IF     = "OTHER_IF"     # other if, condition
OTHER        = "OTHER"        # other,
MULTI_STMT   = "MULTI_STMT"   # & separated statements on one line
RANDOM_OR    = "RANDOM_OR"    # ?-separated options, one picked randomly
FETCH_OPEN   = "FETCH_OPEN"   # @fetch+
FETCH_LINE   = "FETCH_LINE"   # fetch.+from-$+to-
FUNC_CLOSE_CHAIN = "FUNC_CLOSE_CHAIN" # @-& chain to next block
FUNC_CLOSE_END   = "FUNC_CLOSE_END"   # @-# end of chain
TEXT_OPEN    = "TEXT_OPEN"    # @text+
TEXT_LINE    = "TEXT_LINE"    # text:op... lines
TEXT_LENGTH  = "TEXT_LENGTH"  # @text:length+source-
CLEAR_CALL   = "CLEAR_CALL"   # @clear+
IMPORT_CALL  = "IMPORT_CALL"  # @import+

@dataclass
class Token:
    type:  str
    value: str
    line:  int

    def __repr__(self):
        return f"[{self.type}] {self.value!r}  (line {self.line})"


# ── Lexer ──────────────────────────────────────────────────
def tokenize(source: str) -> List[Token]:
    tokens = []
    lines  = source.splitlines()
    in_addfunc = False   # raw-capture mode inside @addfunc

    for line_num, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            if in_addfunc:
                tokens.append(Token("ADDFUNC_LINE", "", line_num))
            continue

        # inside @addfunc block — capture raw lines until @--- or @addfunc:createname
        if in_addfunc:
            if line == "@---":
                tokens.append(Token(ADDFUNC_CLOSE, "@---", line_num))
                in_addfunc = False
                continue
            if re.match(r'^@addfunc:createname"[\w]+"$', line):
                name = re.match(r'^@addfunc:createname"([\w]+)"$', line).group(1)
                tokens.append(Token(ADDFUNC_NAME, name, line_num))
                continue
            # raw body line — store as-is (no comment stripping inside funcs)
            tokens.append(Token("ADDFUNC_LINE", raw, line_num))
            continue

        # strip inline comments — only if | is not inside a +content- block
        if '|' in line and not line.startswith('+'):
            line = line[:line.index('|')].strip()
        if not line:
            continue

        # @---  →  user function close (only valid inside addfunc, but catch it)
        if line == "@---":
            tokens.append(Token(ADDFUNC_CLOSE, "@---", line_num))

        # @output:createname"filename"
        elif re.match(r'^@output:createname".+"$', line):
            name = re.match(r'^@output:createname"(.+)"$', line).group(1)
            tokens.append(Token(OUTPUT_NAME, name, line_num))

        # other if, condition  →  else if
        elif re.match(r'^other if,\s*.+', line):
            cond = line[line.index(',') + 1:].strip()
            tokens.append(Token(OTHER_IF, cond, line_num))

        # other,  →  else
        elif line == 'other,':
            tokens.append(Token(OTHER, 'other', line_num))

        # @dyn:(var) = value  →  dynamic variable assignment
        elif re.match(r'^@dyn:.+', line):
            expr = line[5:].strip()   # strip @dyn:
            tokens.append(Token(DYN_ASSIGN, expr, line_num))

        # @gui:n+content-  →  write to element by id
        elif re.match(r'^@gui:\d+\+.+-$', line):
            m = re.match(r'^@gui:(\d+)\+(.+)-$', line)
            tokens.append(Token(GUI_WRITE, f"{m.group(1)}:{m.group(2)}", line_num))

        # @gui:prop...  →  gui property/element declaration
        elif re.match(r'^@gui:.+', line):
            tokens.append(Token(GUI_PROP, line[1:], line_num))   # strip leading @

        # @gui,print+  or  @gui+  →  gui block open
        elif re.match(r'^@gui[\w,]*\+$', line):
            tokens.append(Token(GUI_OPEN, line, line_num))

        # @fetch+  →  open fetch block
        elif line == "@fetch+":
            tokens.append(Token(FETCH_OPEN, "@fetch+", line_num))

        # fetch.+from-$+to-  →  fetch line
        elif re.match(r'^fetch\.\+.+-\$\+.+-$', line):
            tokens.append(Token(FETCH_LINE, line[7:], line_num))  # strip 'fetch.'

        # @clear+  →  clear terminal
        elif line == "@clear+":
            tokens.append(Token(CLEAR_CALL, "@clear+", line_num))

        # @import+  →  import another .dmg file
        elif line == "@import+":
            tokens.append(Token(IMPORT_CALL, "@import+", line_num))

        # @text+  →  open text block
        elif line == "@text+":
            tokens.append(Token(TEXT_OPEN, "@text+", line_num))

        # @text:length+source-  →  get length
        elif re.match(r'^@text:length\+.+-$', line):
            source = re.match(r'^@text:length\+(.+)-$', line).group(1)
            tokens.append(Token(TEXT_LENGTH, source, line_num))

        # text:op...  →  text operation line
        elif re.match(r'^text:.+', line):
            tokens.append(Token(TEXT_LINE, line, line_num))

        # @addfunc+  →  start user function definition
        elif line == "@addfunc+":
            tokens.append(Token(ADDFUNC_OPEN, "@addfunc+", line_num))
            in_addfunc = True

        # @-# → end of chain
        elif line == "@-#":
            tokens.append(Token(FUNC_CLOSE_END, "@-#", line_num))

        # @-& → chain close  /  @- → normal close
        elif line == "@-&":
            tokens.append(Token(FUNC_CLOSE_CHAIN, "@-&", line_num))

        elif line == "@-":
            tokens.append(Token(FUNC_CLOSE, "@-", line_num))

        # @loop:N  →  loop iteration count
        elif re.match(r"^@loop:\d+$", line):
            n = re.match(r"^@loop:(\d+)$", line).group(1)
            tokens.append(Token(LOOP_COUNT, n, line_num))

        # @var:create+name-  →  create variable from last input
        elif re.match(r"^@var:create\+\w+-$", line):
            name = re.match(r"^@var:create\+(\w+)-$", line).group(1)
            tokens.append(Token(VAR_CREATE, name, line_num))

        # if, <condition>
        elif re.match(r"^if,\s*.+", line):
            cond = line[line.index(",") + 1:].strip()
            tokens.append(Token(IF_COND, cond, line_num))

        # @funcname+ or @funcname,func,func+
        elif re.match(r"^@[\w,]+\+$", line):
            funcs_str = line[1:-1]
            funcs = [f.strip() for f in funcs_str.split(",")]
            tokens.append(Token(FUNC_OPEN, ",".join(funcs), line_num))

        # random-or: line with ? separator between @+...- options
        elif '?' in line and not line.startswith('|') and not line.startswith('+'):
            parts = [p.strip() for p in line.split('?')]
            options = []
            for part in parts:
                if re.match(r"^@[()]*\+.+-$", part):
                    m = re.match(r"^@([()]*)\+(.+)-$", part)
                    options.append(m.group(2))
                elif part.startswith('+') and part.endswith('-'):
                    options.append(part[1:-1])
            tokens.append(Token(RANDOM_OR, '||'.join(options), line_num))

        # multi-statement: line with & separator
        elif '&' in line and not line.startswith('|'):
            parts = [p.strip() for p in line.split('&')]
            tokens.append(Token(MULTI_STMT, str(len(parts)), line_num))
            for part in parts:
                # re-tokenize each part by recursing through detection logic
                if re.match(r"^@[()]*\+.+-$", part):
                    m = re.match(r"^@([()]*)\+(.+)-$", part)
                    depth = m.group(1).count('(')
                    tokens.append(Token(INLINE_CALL, f"{depth}:{m.group(2)}", line_num))
                elif re.match(r"^@[\w,]+\+$", part):
                    funcs_str = part[1:-1]
                    tokens.append(Token(FUNC_OPEN, ",".join(f.strip() for f in funcs_str.split(",")), line_num))
                elif part.startswith("+") and part.endswith("-"):
                    tokens.append(Token(CONTENT, part[1:-1], line_num))
                elif re.match(r"^@-$", part):
                    tokens.append(Token(FUNC_CLOSE, "@-", line_num))
                else:
                    tokens.append(Token(INLINE_CALL, f"0:{part}", line_num))

        # inline call: @+content-  @()+content-  @(())+content-
        elif re.match(r"^@[()]*\+.+-$", line):
            m = re.match(r"^@([()]*)\+(.+)-$", line)
            depth   = m.group(1).count('(')
            content = m.group(2)
            tokens.append(Token(INLINE_CALL, f"{depth}:{content}", line_num))

        # +content-  →  content / argument block
        elif line.startswith("+") and line.endswith("-"):
            content = line[1:-1]
            tokens.append(Token(CONTENT, content, line_num))

        # name+value-  →  variable declaration (inside @var block)
        elif re.match(r"^\w+\+.+-$", line):
            m = re.match(r"^(\w+)\+(.+)-$", line)
            tokens.append(Token(VAR_DECL, f"{m.group(1)}={m.group(2)}", line_num))

        # bare math expression (inside @math block) — digits, ops, or (varname)
        elif re.match(r"^[\d\s\+\-\*\/\.\(\)a-zA-Z_^]+$", line):
            tokens.append(Token(MATH_EXPR, line, line_num))

        else:
            raise SyntaxError(f"line.{line_num}, error unrecognised syntax: {line!r}")

    return tokens
