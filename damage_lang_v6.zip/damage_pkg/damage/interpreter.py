import re
import os
from .parser import (parse_source,
                    ProgramNode, VarBlockNode, VarNode,
                    VarCreateNode, GenericNode, MathNode,
                    IfNode, LoopNode, UserBlockNode,
                    ContainerNode, InlineCallNode, Condition,
                    AddFuncNode, OutputNode, DynAssignNode,
                    GuiWindowNode, GuiElement, GuiWriteNode,
                    IfChainNode, MultiStmtNode, RandomOrNode,
                    VarCreateNode, FetchNode,
                    BlockChainNode, TextNode,
                    ClearNode, ImportNode)


class DamageError(Exception):
    pass


USRFUNC_DIR = os.path.join(os.path.dirname(__file__), 'usrfunc')
OUTPUTS_DIR = os.path.join(os.path.dirname(__file__), 'outputs')
LOGS_DIR    = os.path.join(os.path.expanduser('~'), 'damage', 'logs')
BUILTINS    = {'print', 'var', 'math', 'loop', 'user', 'addfunc', 'output', 'dyn', 'gui', 'random', 'text', 'clear', 'import'}

class Interpreter:
    def __init__(self):
        self.variables    = {}     # name → value (string)
        self._last_input    = '0'    # last thing user typed
        self._context_funcs = []     # current container's func list (for inline calls)
        self._gui_elements  = {}     # id → tkinter widget

    # ── entry point ───────────────────────────────────────
    def run(self, source: str):
        ast = parse_source(source)
        self._exec(ast)

    # ── dispatcher ────────────────────────────────────────
    def _exec(self, node):
        if   isinstance(node, ProgramNode):    self._exec_program(node)
        elif isinstance(node, VarBlockNode):   self._exec_var_block(node)
        elif isinstance(node, VarCreateNode):  self._exec_var_create(node)
        elif isinstance(node, GenericNode):    self._exec_generic(node)
        elif isinstance(node, MathNode):       self._exec_math(node)
        elif isinstance(node, IfNode):         self._exec_if(node)
        elif isinstance(node, IfChainNode):    self._exec_if_chain(node)
        elif isinstance(node, MultiStmtNode):   self._exec_multi(node)
        elif isinstance(node, RandomOrNode):    self._exec_random_or(node)
        elif isinstance(node, FetchNode):        self._exec_fetch(node)
        elif isinstance(node, BlockChainNode):  self._exec_block_chain(node)
        elif isinstance(node, TextNode):         self._exec_text(node)
        elif isinstance(node, ClearNode):        self._exec_clear(node)
        elif isinstance(node, ImportNode):       self._exec_import(node)
        elif isinstance(node, LoopNode):       self._exec_loop(node)
        elif isinstance(node, UserBlockNode):  self._exec_user(node)
        elif isinstance(node, ContainerNode):  self._exec_container(node)
        elif isinstance(node, InlineCallNode): self._exec_inline(node)
        elif isinstance(node, AddFuncNode):     self._exec_addfunc(node)
        elif isinstance(node, OutputNode):       self._exec_output(node)
        elif isinstance(node, DynAssignNode):    self._exec_dyn(node)
        elif isinstance(node, GuiWindowNode):   self._exec_gui(node)

    # ── program ───────────────────────────────────────────
    def _exec_program(self, node: ProgramNode):
        for stmt in node.statements:
            self._exec(stmt)

    # ── variables ─────────────────────────────────────────
    def _exec_var_block(self, node: VarBlockNode):
        for var in node.variables:
            self.variables[var.name] = var.value

    def _exec_var_create(self, node: VarCreateNode):
        self.variables[node.name] = self._last_input

    # ── user input ────────────────────────────────────────
    def _exec_user(self, node: UserBlockNode):
        prompt = self._resolve_content(node.prompt, node.funcs) if node.prompt else ''
        user_in = input(prompt + ' ')
        self._last_input = user_in.strip() or '0'
        if node.var_create:
            self.variables[node.var_create] = self._last_input

    # ── generic (direct content) ──────────────────────────
    def _exec_generic(self, node: GenericNode):
        # check for user-defined functions
        for func in node.funcs:
            if func not in BUILTINS:
                self._call_userfunc(func)
                return
        if 'random' in node.funcs and 'print' not in node.funcs:
            # standalone random — resolve and store via last_input
            self._last_input = self._resolve_random(node.content or '', node.funcs)
            return
        if 'print' in node.funcs and 'random' in node.funcs:
            out = self._resolve_random(node.content or '', node.funcs)
            self._last_input = out
            print(out)
            return
        if 'print' in node.funcs:
            out = self._resolve_content(node.content, node.funcs)
            print(out)

    # ── standalone math ───────────────────────────────────
    def _exec_math(self, node: MathNode):
        import re as _re
        expr = node.expression
        # resolve variable references like (expression) → actual value
        def resolve_var(m):
            inner = m.group(1).strip()
            val = self.variables.get(inner, None)
            return str(val) if val is not None else inner
        expr = _re.sub(r'[(]([^()]+)[)]', resolve_var, expr)
        result = self._eval_math(expr)
        self._last_input = result
        self.variables['__mathresult__'] = result
        print(result)

    # ── if ────────────────────────────────────────────────
    def _exec_if(self, node: IfNode):
        if self._eval_conditions(node.conditions):
            self._exec(node.body)

    # ── clear terminal ───────────────────────────────────────
    def _exec_clear(self, node: ClearNode):
        os.system('clear' if os.name != 'nt' else 'cls')

    # ── import .dmg file ──────────────────────────────────────
    def _exec_import(self, node: ImportNode):
        path = node.path.strip()
        if not path.endswith('.dmg'):
            path += '.dmg'
        # resolve relative to current working directory
        if not os.path.isabs(path):
            path = os.path.join(os.getcwd(), path)
        if not os.path.exists(path):
            self.log_error(f'@import: file not found: {path}')
            return
        with open(path, 'r') as f:
            source = f.read()
        # run in same interpreter — shares variables and functions
        from .parser import parse_source
        ast = parse_source(source)
        self._exec(ast)

    # ── text operations ──────────────────────────────────────
    def _exec_text(self, node: TextNode):
        import re as _re

        # handle @text:length
        if node.length_source:
            src = node.length_source
            if src.startswith('@var/'):
                val = str(self.variables.get(src[5:], ''))
            elif src == '@user':
                val = str(self._last_input)
            else:
                # file path
                path = os.path.expanduser(src)
                if os.path.exists(path):
                    with open(path, 'r') as f:
                        val = f.read()
                else:
                    val = ''
            length = str(len(val))
            print(length)
            self._last_input = length
            if node.var_create:
                self.variables[node.var_create] = length
            return

        # handle other text operations
        for op in node.operations:
            if op[0] == 'maxlength':
                limit = op[1]
                # apply to last input or recent variable
                val = str(self._last_input)
                if len(val) > limit:
                    self.log_error(f'text:maxlength — value exceeds maximum length of {limit}')
                return

            elif op[0] in ('capital', 'lower'):
                _, ref, pos = op
                # ref format: @var/name/S or /path/S
                m = _re.match(r'@var/(\w+)/(.+)', ref)
                if m:
                    varname, target_char = m.group(1), m.group(2)
                    val = str(self.variables.get(varname, ''))
                    # find the character at position (1-indexed)
                    idx = pos - 1
                    if 0 <= idx < len(val) and val[idx].lower() == target_char.lower():
                        if op[0] == 'capital':
                            val = val[:idx] + val[idx].upper() + val[idx+1:]
                        else:
                            val = val[:idx] + val[idx].lower() + val[idx+1:]
                        self.variables[varname] = val

    # ── block chain (@-&) ────────────────────────────────────
    def _exec_block_chain(self, node: BlockChainNode):
        for block in node.blocks:
            self._exec(block)

    # ── fetch ($) ────────────────────────────────────────────
    def _exec_fetch(self, node: FetchNode):
        import re
        for source, target in node.pipes:
            value = self._fetch_read(source)
            self._fetch_write(target, value)

    def _fetch_read(self, ref: str) -> str:
        import re
        # @var/varname
        m = re.match(r'^@var/(\w+)$', ref)
        if m:
            return str(self.variables.get(m.group(1), ''))

        # gui:n — read from GUI widget (stored in _gui_elements)
        m = re.match(r'^gui:(\w+)$', ref)
        if m:
            eid = m.group(1)
            if hasattr(self, '_gui_elements') and eid in self._gui_elements:
                w = self._gui_elements[eid]
                if hasattr(w, 'get'):
                    return w.get()
            return ''

        # /path/to/file — read file contents
        if ref.startswith('/') or ref.startswith('./') or ref.startswith('~'):
            path = os.path.expanduser(ref)
            if os.path.exists(path):
                with open(path, 'r') as f:
                    return f.read().strip()
            return ''

        # @funcname — run function, capture stdout
        m = re.match(r'^@(\w+)$', ref)
        if m:
            import io
            old_stdout = __import__('sys').stdout
            __import__('sys').stdout = io.StringIO()
            self._call_userfunc(m.group(1))
            out = __import__('sys').stdout.getvalue()
            __import__('sys').stdout = old_stdout
            return out.strip()

        return ref   # literal fallback

    def _fetch_write(self, ref: str, value: str):
        import re
        # @var/varname
        m = re.match(r'^@var/(\w+)$', ref)
        if m:
            self.variables[m.group(1)] = value
            return

        # gui:n — write to GUI widget
        m = re.match(r'^gui:(\w+)$', ref)
        if m:
            eid = m.group(1)
            if hasattr(self, '_gui_elements') and eid in self._gui_elements:
                w = self._gui_elements[eid]
                if hasattr(w, 'delete') and hasattr(w, 'insert'):
                    w.delete(0, 'end')
                    w.insert(0, value)
                elif hasattr(w, 'config'):
                    w.config(text=value)
            return

        # /path/to/file — write to file
        if ref.startswith('/') or ref.startswith('./') or ref.startswith('~'):
            path = os.path.expanduser(ref)
            os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
            with open(path, 'w') as f:
                f.write(value)
            return

    # ── random or (?) ────────────────────────────────────────
    def _exec_random_or(self, node: RandomOrNode):
        import random
        choice = random.choice(node.options)
        out    = self._resolve_content(choice, self._context_funcs if self._context_funcs else ['print'])
        print(out)

    # ── multi statement (&) ──────────────────────────────────
    def _exec_multi(self, node: MultiStmtNode):
        for stmt in node.statements:
            self._exec(stmt)

    # ── if chain (other if / other) ──────────────────────────
    def _exec_if_chain(self, node: IfChainNode):
        for conditions, body in node.branches:
            if conditions is None:
                # other, (else) — always runs if we reach it
                self._exec(body)
                return
            if self._eval_conditions(conditions):
                self._exec(body)
                return   # first match wins, stop here

    # ── loop ──────────────────────────────────────────────
    def _exec_loop(self, node: LoopNode):
        count = None
        if node.static_count is not None:
            count = node.static_count
        else:
            for conds, n in node.dyn_conditions:
                if self._eval_conditions(conds):
                    count = n
                    break

        if not count:
            return

        full_funcs = ['loop'] + node.funcs
        for _ in range(count):
            out = self._resolve_content(node.content, full_funcs)
            if 'print' in node.funcs:
                print(out)

    # ── container (if+inline block) ───────────────────────
    def _exec_container(self, node: ContainerNode):
        prev = self._context_funcs
        self._context_funcs = node.funcs

        for stmt in node.statements:
            if 'random' in node.funcs and isinstance(stmt, InlineCallNode):
                result = self._resolve_random(stmt.content, node.funcs)
                self._last_input = result
                if 'print' in node.funcs:
                    print(result)
            elif 'random' in node.funcs and isinstance(stmt, VarCreateNode):
                self.variables[stmt.name] = self._last_input
            else:
                self._exec(stmt)

        self._context_funcs = prev

    # ── inline call (@+content-) ──────────────────────────
    def _exec_inline(self, node: InlineCallNode):
        funcs = self._context_funcs if self._context_funcs else ['print']
        func  = funcs[node.depth] if node.depth < len(funcs) else 'print'
        if func == 'print':
            out = self._resolve_content(node.content, funcs)
            print(out)

    # ── content resolver ──────────────────────────────────
    def _resolve_content(self, content: str, funcs: list) -> str:
        if not content:
            return ''

        # depth → function  (depth 0 = primary, never wrapped)
        paren_map = {i: f for i, f in enumerate(funcs) if i > 0}

        MATH_OPS = {'+', '-', '*', '/'}

        def replace(m):
            depth = len(m.group(1))
            inner = m.group(2).strip()
            func  = paren_map.get(depth)

            # figure out by content first — depth is a hint, not a rule
            if inner in self.variables:
                return str(self.variables[inner])        # it's a variable name
            if inner in MATH_OPS:
                return inner                             # it's a math operator symbol
            # strict match as last resort
            if func == 'var':
                return f'[UNDEFINED:{inner}]'
            return inner                                 # pass through

        resolved = re.sub(r'(\(+)([^()]+)(\)+)', replace, content)

        # process %expr% inline math BEFORE safety check
        if 'math' in funcs and '%' in resolved:
            import re as _re2
            _results = []
            def _extract(m):
                expr = m.group(1)
                # resolve operator symbols like (+) -> +
                expr = _re2.sub(r'[(]([+*^/-])[)]', lambda x: x.group(1), expr)
                # resolve variables
                def _rv(mv):
                    inner = mv.group(1).strip()
                    v = self.variables.get(inner)
                    return str(v) if v is not None else inner
                expr = _re2.sub(r'[(]+([^()]+)[)]+', _rv, expr)
                result = self._eval_math(expr.strip())
                _results.append(result)
                return ''
            resolved = _re2.sub(r'%([^%]+)%', _extract, resolved)
            _idx = [0]
            def _place(m):
                if _idx[0] < len(_results):
                    r = _results[_idx[0]]; _idx[0] += 1; return r
                return ''
            resolved = _re2.sub(r'%', _place, resolved)

        # validate: if math ops appear outside parens and math not declared, error
        if 'math' not in funcs and 'random' not in funcs:
            import re as _re
            bad = _re.findall(r'(?<=[0-9a-zA-Z])\s*([+])\s*(?=[0-9a-zA-Z])', resolved)
            for b in bad:
                self.log_error(f'"{b}" is an unclosed opener. Maybe you forgot to declare math?')

        return resolved

    # ── random resolver ──────────────────────────────────────
    def _resolve_random(self, content: str, funcs: list) -> str:
        import random, re as _re

        # First resolve any variable references in content
        def resolve_vars(c):
            def rep(m):
                inner = m.group(2).strip()
                if inner in self.variables:
                    return str(self.variables[inner])
                return inner
            return _re.sub(r'(\(+)([^()]+)(\)+)', rep, c)

        resolved = resolve_vars(content)

        # Check if it's variable-mode: multiple ((...)) groups separated by commas
        var_matches = _re.findall(r'\(+([^()]+)\++', content)

        # Split by comma to get items — but only top-level commas
        # Strip any remaining parens
        items = [i.strip().strip('()') for i in resolved.split(',')]
        items = [i for i in items if i]

        if len(items) == 1:
            # Check if it's a range like "1-10"
            range_match = _re.match(r'^(\d+)-(\d+)$', items[0])
            if range_match:
                lo, hi = int(range_match.group(1)), int(range_match.group(2))
                return str(random.randint(lo, hi))

        return str(random.choice(items))

    # ── math evaluator ────────────────────────────────────
    def _eval_math(self, expr: str) -> str:
        try:
            expr = expr.replace('^', '**')
            if re.search(r'[^0-9a-zA-Z_ +\-*/.()^]', expr):
                return f'[MATH ERROR: unsafe chars in {expr!r}]'
            # cap exponent size to prevent freeze
            import re as _re2
            exponents = _re2.findall(r'\*\*(\d+)', expr)
            for e in exponents:
                if int(e) > 1000:
                    return 'too large to display'
            result = eval(expr)
            return self._format_number(result)
        except OverflowError:
            return 'too large to display'
        except ValueError as e:
            if 'digits' in str(e):
                return 'too large to display'
            return f'[MATH ERROR: {e}]'
        except Exception as e:
            return f'[MATH ERROR: {e}]'

    def _format_number(self, n) -> str:
        """Format a number — scientific notation if >= 10^10"""
        try:
            f = float(n)
            # if it's a whole number, work with int
            if f == int(f):
                i = int(f)
                if abs(i) >= 10_000_000_000:
                    # express as X^Y if it's a perfect power, otherwise scientific
                    import math
                    exp = int(math.log10(abs(i)))
                    mantissa = i / (10 ** exp)
                    if mantissa == 1.0:
                        return f"10^{exp}"
                    elif mantissa == int(mantissa):
                        return f"{int(mantissa)}x10^{exp}"
                    else:
                        return f"{mantissa:.4g}x10^{exp}"
                return str(i)
            else:
                if abs(f) >= 10_000_000_000:
                    import math
                    exp = int(math.log10(abs(f)))
                    mantissa = f / (10 ** exp)
                    return f"{mantissa:.4g}x10^{exp}"
                # round floats to avoid 0.1+0.2=0.30000000000000004
                return str(round(f, 10)).rstrip('0').rstrip('.')
        except:
            return str(n)

    # ── condition evaluator ───────────────────────────────
    def _eval_conditions(self, conditions: list) -> bool:
        return all(self._eval_single(c) for c in conditions)

    def _eval_single(self, cond: Condition) -> bool:
        left  = self._resolve_val(cond.left)
        right = self._resolve_val(cond.right)
        try:
            l, r = float(left), float(right)
            return {'=': l==r, '<': l<r, '>': l>r, '~': l!=r}.get(cond.op, False)
        except ValueError:
            return {'=': left==right, '~': left!=right}.get(cond.op, False)

    def _resolve_val(self, val: str) -> str:
        stripped = re.sub(r'^\(+|\)+$', '', val.strip())
        return str(self.variables.get(stripped, stripped))


    # ── dynamic variable assignment ──────────────────────────
    def _exec_dyn(self, node: DynAssignNode):
        MATH_OPS = set('+-*/')
        for varname, expr in node.assignments:
            # strip parens from varname
            name = varname.strip('()')

            if name not in self.variables:
                self.log_error(f"@dyn: variable '{name}' does not exist — declare it with @var first")
                continue

            # resolve the right-hand side
            # replace (varname) refs with their values
            import re
            def resolve_ref(m):
                inner = m.group(1)
                if inner in self.variables:
                    return str(self.variables[inner])
                return inner
            resolved = re.sub(r'\(([^()]+)\)', resolve_ref, expr)

            # if it looks like a math expression, evaluate it
            try:
                resolved = resolved.replace('^', '**')
                if any(op in resolved for op in MATH_OPS) or '**' in resolved:
                    result = str(eval(resolved))
                else:
                    result = resolved.strip()
            except Exception as e:
                self.log_error(f"@dyn: could not evaluate '{resolved}': {e}")
                continue

            self.variables[name] = result

    # ── GUI ─────────────────────────────────────────────────────
    def _exec_gui(self, node):
        try:
            import tkinter as tk
        except ImportError:
            self.log_error("GUI requires tkinter (comes with Python)")
            return

        root = tk.Tk()
        root.title(node.title)
        root.geometry(f"{node.width}x{node.height}")
        root.configure(bg='#1e1e2e')

        # colors
        BG   = '#1e1e2e'
        FG   = '#cdd6f4'
        BTN  = '#313244'
        ACC  = '#cba6f7'
        FONT = ('Courier', 13)

        element_widgets = {}   # id → widget

        # build elements
        for elem in node.elements:
            content = self._resolve_content(elem.content, ['gui', 'var'])

            if elem.kind == 'text':
                x, y = elem.pos
                clean = re.sub(r':pos\+[^-]+-$', '', content).strip()
                lbl = tk.Label(root, text=clean, bg=BG, fg=FG, font=FONT)
                lbl.place(x=x, y=node.height - y - 30)
                if elem.elem_id:
                    element_widgets[elem.elem_id] = lbl
                self._gui_elements[elem.elem_id] = lbl

            elif elem.kind == 'input':
                entry = tk.Entry(root, font=FONT, bg=BTN, fg=FG,
                                 insertbackground=FG, relief='flat', bd=6)
                placeholder = content
                entry.insert(0, placeholder)
                entry.config(fg='#6c7086')

                def on_focus_in(e, ent=entry, ph=placeholder):
                    if ent.get() == ph:
                        ent.delete(0, 'end')
                        ent.config(fg=FG)

                def on_focus_out(e, ent=entry, ph=placeholder):
                    if not ent.get():
                        ent.insert(0, ph)
                        ent.config(fg='#6c7086')

                entry.bind('<FocusIn>', on_focus_in)
                entry.bind('<FocusOut>', on_focus_out)
                entry.pack(pady=8, padx=20, fill='x')
                element_widgets[elem.elem_id] = entry
                self._gui_elements[elem.elem_id] = entry

            elif elem.kind == 'pressable':
                btn_name = elem.name
                # find handler for this button
                handler_body = None
                for hname, hbody in node.handlers:
                    if hname == btn_name:
                        handler_body = hbody
                        break

                def make_cmd(body, bname, interp=self, ew=element_widgets):
                    def cmd():
                        if body:
                            if hasattr(body, 'content'):
                                content = body.content
                                # __calc__:from_id:to_id — read, eval, write
                                import re as _re
                                cm = _re.match(r'^__calc__:(\w+):(\w+)$', content)
                                if cm:
                                    from_id, to_id = cm.group(1), cm.group(2)
                                    expr = ew.get(from_id, None)
                                    if expr and hasattr(expr, 'get'):
                                        expression = expr.get()
                                        try:
                                            # safe eval — numbers and operators only
                                            expression = expression.replace('^', '**')
                                            if _re.search(r'[^0-9\s\+\-\*\/\.\(\)\*]', expression):
                                                res = 'ERROR: invalid characters'
                                            else:
                                                res = str(eval(expression))
                                        except Exception as e:
                                            res = f'ERROR: {e}'
                                        target = ew.get(to_id, None)
                                        if target and hasattr(target, 'delete'):
                                            target.delete(0, 'end')
                                            target.insert(0, res)
                                else:
                                    out = interp._resolve_content(content, ['gui', 'print'])
                                    result_label.config(text=out)
                            else:
                                interp._gui_elements = ew
                                interp._exec(body)
                    return cmd

                btn = tk.Button(root, text=btn_name, command=make_cmd(handler_body, btn_name),
                                bg=ACC, fg=BG, font=FONT, relief='flat',
                                padx=12, pady=6, cursor='hand2')
                if elem.pos != (0, 0):
                    x, y = elem.pos
                    btn.place(x=x, y=node.height - y - 40)
                else:
                    btn.pack(pady=8)

        # result label for button outputs
        result_label = tk.Label(root, text='', bg=BG, fg=ACC, font=FONT)
        result_label.pack(pady=4)

        root.mainloop()

    # ── file output ──────────────────────────────────────────
    def _exec_output(self, node: OutputNode):
        if not node.filename:
            self.log_error("output block missing @output:createname")
            return
        content = self._resolve_content(node.content, node.funcs)
        os.makedirs(OUTPUTS_DIR, exist_ok=True)
        path = os.path.join(OUTPUTS_DIR, node.filename)
        with open(path, 'w') as f:
            f.write(content + '\n')

    # ── error logging ─────────────────────────────────────────
    def log_error(self, msg: str, line: int = None):
        if line:
            display = f"ERROR:\nline.{line}, error {msg}"
        else:
            display = f"ERROR:\n{msg}"
        raise DamageError(display)

    # ── define user function ─────────────────────────────────
    def _exec_addfunc(self, node: AddFuncNode):
        if node.name is None:
            print("  ⚠  @addfunc: missing @addfunc:createname before @---")
            return
        if node.name in BUILTINS:
            self.log_error(f'function name "{node.name}" conflicts with built-in')
            return
        os.makedirs(USRFUNC_DIR, exist_ok=True)
        path = os.path.join(USRFUNC_DIR, f"{node.name}.func")
        with open(path, 'w') as f:
            f.write(node.body)

    # ── call user function ────────────────────────────────────
    def _call_userfunc(self, name: str):
        path = os.path.join(USRFUNC_DIR, f"{name}.func")
        if not os.path.exists(path):
            self.log_error(f"unknown function @{name}")
            return
        with open(path, 'r') as f:
            source = f.read()
        # run inside a child interpreter sharing variables
        child = Interpreter()
        child.variables = self.variables
        child.run(source)
        self.variables = child.variables   # sync back


# ── run a .dmg file ───────────────────────────────────────
def run_file(path: str):
    with open(path, 'r') as f:
        source = f.read()
    Interpreter().run(source)


if __name__ == "__main__":
    run_file("test.dmg")
