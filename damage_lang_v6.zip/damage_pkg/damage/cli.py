import sys
import os
import datetime
import argparse
from .interpreter import Interpreter, DamageError

LOGS_DIR    = os.path.join(os.path.expanduser('~'), 'damage', 'logs')
USRFUNC_DIR = os.path.join(os.path.dirname(__file__), 'usrfunc')
VERSION     = "6.0"

# ── Help Text ─────────────────────────────────────────────────────────────────

HELP = """
DAMAGE v{version} — A programming language built on your logic.
================================================================

USAGE:
  damage <file.dmg> [flags]
  damage [command]

FLAGS:
  -h,  --help           Show this help guide
  -v,  --version        Show DAMAGE version
  -c,  --check          Check syntax without running
  -d,  --debug          Show tokens and AST before running
  -q,  --quiet          Suppress all output except errors
  -l,  --log            Always save errors to logs (no prompt)
  -n,  --no-log         Never save errors to logs (no prompt)
  -o,  --output <dir>   Set custom output directory for @output blocks
       --list-funcs     List all saved user functions
       --clear-logs     Delete all saved logs
       --clear-funcs    Delete all saved user functions

================================================================
SYNTAX GUIDE
================================================================

COMMENTS
  | Anything after a pipe is a comment
  @print+
       +Hello!- | this is also a comment
  @-

----------------------------------------------------------------
VARIABLES
----------------------------------------------------------------

  Declare:
    @var+
         name+value-
    @-

  Boolean (1=on, 0=off):
    @var+
         isAlive=1
    @-

  List (one call, displays all):
    @var+
         groceries+apples,bananas,milk-
    @-

  Reassign dynamically:
    @dyn,var+
    @dyn:(name) = newvalue
    @-

    Math in reassign:
    @dyn,var+
    @dyn:(score) = (score)+10
    @-

    Copy variable:
    @dyn,var+
    @dyn:(score) = (lives)
    @-

----------------------------------------------------------------
PRINT
----------------------------------------------------------------

  Basic:
    @print+
         +Hello world-
    @-

  With variable:
    @print,var+
         +(name) is here-
    @-

  With math operator display:
    @print,math+
         +2 (+) 2 = 4-
    @-

  With variable AND math:
    @print,math,var+
         +(score) (+) 1 = great-
    @-

PAREN DEPTH RULE:
  Position in function list - 1 = layers of parens.
  @print,math,var+
       +((score)) (+) 1-
  @-
  print=0 (no parens), math=1 → (+), var=2 → ((score))

  DAMAGE is forgiving — it matches by content, not just depth.
  If it's a known variable name, it resolves it regardless of depth.

----------------------------------------------------------------
MATH
----------------------------------------------------------------

  Standalone:
    @math+
         10+5
    @-

  Operators: + - * /
  Order of operations follows standard rules.

----------------------------------------------------------------
CONDITIONS
----------------------------------------------------------------

  Basic if:
    if, (score) = 5
    @print+
         +Perfect!-
    @-

  Else if:
    if, (score) = 5
    @print+
         +Perfect!-
    @-
    other if, (score) > 5
    @print+
         +Too high-
    @-
    other,
    @print+
         +Too low-
    @-

  Operators:
    =   equals
    <   less than
    >   greater than
    ~   not equal

  Chained AND conditions:
    if, (score) = 5,(lives) > 0,(name) = Fred
    @print+
         +All conditions met-
    @-

  Multi-statement on true (&):
    if, (score) = 5
         @+You win!-&@+Score saved.-&@+Well done.-

  First match wins — once a branch fires, rest are skipped.

----------------------------------------------------------------
LOOPS
----------------------------------------------------------------

  Fixed count:
    @loop,print+
         +Hello!-
    @loop:5
    @-

  Conditional count:
    @loop,print+
         +Hello!-
    if, (score) = 5
    @loop:3
    if, (score) > 5
    @loop:0
    @-

  @loop:0 means skip entirely.

----------------------------------------------------------------
USER INPUT
----------------------------------------------------------------

  Get input:
    @user,print+
         +What is your name?-
    @var:create+name-
    @-

  @var:create stores the last input as a variable.
  Default value is 0 if user inputs nothing.

----------------------------------------------------------------
RANDOM
----------------------------------------------------------------

  From explicit list:
    @print,random+
         @()+1,2,3,4,5-
    @var:create+pick-
    @-

  From range:
    @print,random+
         @()+1-100-
    @var:create+pick-
    @-

  From variables:
    @print,random+
         @()+((score)),((lives)),((gold))-
    @var:create+pick-
    @-

  Random OR — picks one randomly, works anywhere:
    @+Good job!-?@+Well done!-?@+Excellent!-

  Works inside conditions too:
    if, (score) = 5
         @+Perfect!-?@+Flawless!-?@+Amazing!-

----------------------------------------------------------------
USER FUNCTIONS
----------------------------------------------------------------

  Define:
    @addfunc+
    @print+
         +Hello from my function!-
    @-
    @addfunc:createname"greet"
    @---

  Call:
    @greet+
    @-

  Saved as .func files in /damage_pkg/damage/usrfunc/
  Variables are shared between caller and function.
  Cannot name a function after a built-in (print, var, etc.)

----------------------------------------------------------------
FILE OUTPUT
----------------------------------------------------------------

  Write to file:
    @output,var+
         +(result)-
    @output:createname"results.txt"
    @-

  Saved to /damage_pkg/damage/outputs/

----------------------------------------------------------------
GUI
----------------------------------------------------------------

  Open a window:
    @gui,print,var+
    @gui:winname"My App"
    @gui:winsize"800:600"
    @gui:text+(greeting)-:pos+100,300-
    @gui:input:text+Type here...-:1
    @gui:input:writableelement:text+Writable field-:2
    @gui:pressable"name:Click Me":pos+300,200-
    if, pressable+Click Me-:true
         @()+Button was clicked!-
    @-

  Coordinates origin is bottom-left.
  X = right, Y = up.
  Element IDs (:n) used for referencing elements.

  Write to writable element:
    @gui+
    @gui:2+New content!-
    @-

----------------------------------------------------------------
ERRORS
----------------------------------------------------------------

  Format:
    ERROR:
    line.N, error "description"

  On crash:
    - Program stops immediately
    - Prompts: Save to logs? [y/n]
    - y saves to ~/damage/logs/damage.log with timestamp
    - n discards

----------------------------------------------------------------
MATH INLINE EVALUATION
----------------------------------------------------------------

  Use %expr% to evaluate math inline in a print block:
    @print,math+
         +2(+)2 = %2 (+) 2%? Yes! 2+2 = %-
    @-
  Output: 2+2 = ? Yes! 2+2 = 4

  Exponents use ^:
    @print,math+
         +2^10 = %2^10%-
    @-
  Results >= 10^10 display in scientific notation automatically.
  Results too large display as: too large to display

----------------------------------------------------------------
TEXT OPERATIONS
----------------------------------------------------------------

  Get length:
    @text+
    @text:length+@var/varname-
    @var:create+mylen-
    @-

    Sources: @var/name  /file/path  @user

  Capitalize letter at position:
    @text+
    text:capital"@var/name/s":1
    @-

  Lowercase letter at position:
    @text+
    text:lower"@var/name/S":1
    @-

  Max length (errors if exceeded):
    @text+
    text:maxlength"15"
    @-

----------------------------------------------------------------
FETCH — UNIVERSAL DATA PIPELINE
----------------------------------------------------------------

  Pipe anything to anything with $:
    @fetch+
    fetch.+@var/score-$+@var/backup-    | var → var
    fetch.+gui:1-$+@var/input-          | gui element → var
    fetch.+@var/name-$+gui:2-           | var → gui element
    fetch.+@var/data-$+/path/out.txt-   | var → file
    fetch.+/path/in.txt-$+@var/data-    | file → var
    fetch.+@funcname-$+@var/result-     | function output → var
    @-

----------------------------------------------------------------
BLOCK CHAINING
----------------------------------------------------------------

  Chain multiple blocks with @-& and end with @-#:
    if, pressable+Btn-:true
         @fetch+
         fetch.+gui:1-$+@var/input-
    @-&
    @math,var+
         +(input)-
    @-&
    @fetch+
         fetch.+@var/__mathresult__-$+gui:2-
    @-#

  @-&   end this block, more coming
  @-#   end of entire chain
  @-    normal block close

----------------------------------------------------------------
RANDOM
----------------------------------------------------------------

  From list:   @()+1,2,3,4,5-
  From range:  @()+1-100-
  From vars:   @()+((score)),((lives))-

  Random OR — pick one randomly:
    @+Nice!-?@+Great!-?@+Amazing!-

----------------------------------------------------------------
ELSE IF / ELSE
----------------------------------------------------------------

  if, (score) = 5
  @print+
       +Perfect!-
  @-
  other if, (score) > 5
  @print+
       +Too high-
  @-
  other,
  @print+
       +Too low-
  @-

----------------------------------------------------------------
MULTI-STATEMENT (&) AND RANDOM OR (?)
----------------------------------------------------------------

  & runs all in order:
    if, (score) = 5
         @+You win!-&@+Score saved.-&@+Well done.-

  ? picks one randomly:
    @+Good job!-?@+Well done!-?@+Amazing!-

================================================================
BUILT-IN FUNCTIONS
================================================================

  print     — output text to terminal
  var       — declare/reference variables
  math      — math operators in print, inline eval with %
  loop      — repeat a block
  user      — get input from user
  random    — pick randomly from list/range/variables
  output    — write to file
  gui       — open a GUI window
  dyn       — dynamically reassign variables
  addfunc   — define a user function
  text      — string operations (length, capital, lower, maxlength)
  fetch     — universal data pipeline
  clear     — clear the terminal
  import    — import another .dmg file

================================================================
INDENTATION
================================================================

  5 spaces — strictly enforced.
  Wrong indentation will cause a syntax error.

================================================================
FILE STRUCTURE
================================================================

  damage_pkg/
  ├── pyproject.toml
  └── damage/
      ├── lexer.py
      ├── parser.py
      ├── interpreter.py
      ├── cli.py
      ├── usrfunc/      ← user functions (.func files)
      ├── outputs/      ← file output
      └── logs/         (in ~/damage/logs/)

================================================================
""".format(version=VERSION)


# ── Helpers ───────────────────────────────────────────────────────────────────

def save_log(error_msg: str, path: str):
    os.makedirs(LOGS_DIR, exist_ok=True)
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_file  = os.path.join(LOGS_DIR, 'damage.log')
    with open(log_file, 'a') as f:
        f.write(f"[{timestamp}] file: {path}\n")
        f.write(f"{error_msg}\n")
        f.write("-" * 40 + "\n")
    print(f"Saved to {log_file}")

def prompt_save(error_msg: str, path: str, always: bool, never: bool):
    if always:
        save_log(error_msg, path)
    elif never:
        pass
    else:
        try:
            answer = input("\nSave to logs? [y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = 'n'
        if answer == 'y':
            save_log(error_msg, path)

def list_funcs():
    if not os.path.exists(USRFUNC_DIR):
        print("No user functions saved yet.")
        return
    funcs = [f[:-5] for f in os.listdir(USRFUNC_DIR) if f.endswith('.func')]
    if not funcs:
        print("No user functions saved yet.")
    else:
        print(f"Saved user functions ({len(funcs)}):")
        for f in sorted(funcs):
            print(f"  @{f}")

def clear_logs():
    log_file = os.path.join(LOGS_DIR, 'damage.log')
    if os.path.exists(log_file):
        os.remove(log_file)
        print("Logs cleared.")
    else:
        print("No logs to clear.")

def clear_funcs():
    if not os.path.exists(USRFUNC_DIR):
        print("No user functions to clear.")
        return
    funcs = [f for f in os.listdir(USRFUNC_DIR) if f.endswith('.func')]
    for f in funcs:
        os.remove(os.path.join(USRFUNC_DIR, f))
    print(f"Cleared {len(funcs)} user function(s).")

def check_syntax(source: str, path: str):
    from .lexer import tokenize
    from .parser import parse_source
    try:
        tokens = tokenize(source)
        ast    = parse_source(source)
        print(f"OK — {path} syntax looks good.")
    except SyntaxError as e:
        print(f"ERROR:\n{e}")
        sys.exit(1)

def debug_run(source: str):
    from .lexer import tokenize
    from .parser import parse_source, pretty
    print("── Tokens ─────────────────────────────")
    for tok in tokenize(source):
        print(tok)
    print("\n── AST ─────────────────────────────────")
    ast = parse_source(source)
    pretty(ast)
    print("\n── Output ──────────────────────────────")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    # handle no args
    if len(sys.argv) < 2:
        print(f"DAMAGE v{VERSION} — damage --help for guide")
        sys.exit(0)

    # handle commands before argparse
    if sys.argv[1] in ('-h', '--help'):
        print(HELP)
        sys.exit(0)
    if sys.argv[1] in ('-v', '--version'):
        print(f"DAMAGE v{VERSION}")
        sys.exit(0)
    if sys.argv[1] == '--list-funcs':
        list_funcs(); sys.exit(0)
    if sys.argv[1] == '--clear-logs':
        clear_logs(); sys.exit(0)
    if sys.argv[1] == '--clear-funcs':
        clear_funcs(); sys.exit(0)

    # parse flags
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('file',          nargs='?')
    parser.add_argument('-c', '--check', action='store_true')
    parser.add_argument('-d', '--debug', action='store_true')
    parser.add_argument('-q', '--quiet', action='store_true')
    parser.add_argument('-l', '--log',   action='store_true')
    parser.add_argument('-n', '--no-log',action='store_true', dest='nolog')
    parser.add_argument('-o', '--output',type=str, default=None)

    args = parser.parse_args()

    if not args.file:
        print(f"DAMAGE v{VERSION} — damage --help for guide")
        sys.exit(0)

    if not os.path.exists(args.file):
        print(f"ERROR:\nfile not found: {args.file}")
        sys.exit(1)

    with open(args.file, 'r') as f:
        source = f.read()

    # --check
    if args.check:
        check_syntax(source, args.file)
        sys.exit(0)

    # --debug
    if args.debug:
        debug_run(source)

    # run
    try:
        interp = Interpreter()
        if args.quiet:
            import io
            sys.stdout = io.StringIO()
        if args.output:
            interp._output_dir = args.output
        interp.run(source)
        if args.quiet:
            sys.stdout = sys.__stdout__

    except DamageError as e:
        if args.quiet:
            sys.stdout = sys.__stdout__
        print(str(e))
        prompt_save(str(e), args.file, args.log, args.nolog)
        sys.exit(1)

    except SyntaxError as e:
        if args.quiet:
            sys.stdout = sys.__stdout__
        msg = f"ERROR:\n{e}"
        print(msg)
        prompt_save(msg, args.file, args.log, args.nolog)
        sys.exit(1)

    except KeyboardInterrupt:
        if args.quiet:
            sys.stdout = sys.__stdout__
        print("\nProgram interrupted.")
        sys.exit(0)
