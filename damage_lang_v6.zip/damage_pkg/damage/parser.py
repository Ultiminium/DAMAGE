import re
from dataclasses import dataclass, field
from typing import List, Optional, Any, Tuple
from .lexer import (tokenize, Token,
                   FUNC_OPEN, FUNC_CLOSE, CONTENT, VAR_DECL,
                   VAR_CREATE, LOOP_COUNT, IF_COND, MATH_EXPR, INLINE_CALL,
                   ADDFUNC_OPEN, ADDFUNC_NAME, ADDFUNC_CLOSE,
                   OUTPUT_NAME, DYN_ASSIGN,
                   GUI_OPEN, GUI_PROP, GUI_WRITE,
                   OTHER_IF, OTHER,
                   MULTI_STMT, RANDOM_OR,
                   FETCH_OPEN, FETCH_LINE,
                   FUNC_CLOSE_CHAIN, FUNC_CLOSE_END,
                   TEXT_OPEN, TEXT_LINE, TEXT_LENGTH,
                   CLEAR_CALL, IMPORT_CALL)


# ── AST Nodes ──────────────────────────────────────────────

@dataclass
class VarNode:
    name:  str
    value: str

@dataclass
class VarBlockNode:
    variables: List[VarNode]

@dataclass
class VarCreateNode:
    name: str          # variable name to store last input into

@dataclass
class Condition:
    left:  str
    op:    str         # = < > ~
    right: str

@dataclass
class IfNode:
    conditions: List[Condition]
    body: Any

@dataclass
class MathNode:
    expression: str

@dataclass
class LoopNode:
    funcs:          List[str]
    content:        Optional[str]
    static_count:   Optional[int]
    dyn_conditions: List[Tuple[List[Condition], int]]

@dataclass
class GenericNode:
    """Direct content block — @print,var+ +content- @-"""
    funcs:   List[str]
    content: Optional[str]

@dataclass
class UserBlockNode:
    """@user,... block — shows prompt, waits for input, optionally saves"""
    funcs:      List[str]
    prompt:     Optional[str]
    var_create: Optional[str]   # variable name to save input into

@dataclass
class ContainerNode:
    """Block whose body is if+inline-call pairs, not direct content"""
    funcs:      List[str]
    statements: List[Any]

@dataclass
class InlineCallNode:
    """@+content-  or  @(())+content-  inside a container"""
    depth:   int            # number of open parens = func position - 1
    content: str

@dataclass
class ProgramNode:
    statements: List[Any]


# ── Condition Parser ───────────────────────────────────────

def parse_conditions(raw: str) -> List[Condition]:
    import re as _re
    parts = [p.strip() for p in raw.split(',')]
    conds = []
    for part in parts:
        # gui pressable handler — pass through as special condition
        if _re.match(r'pressable\+.+\-:true', part):
            conds.append(Condition('__gui_pressable__', '=', part))
            continue
        matched = False
        for op in ['~', '<', '>', '=']:
            if op in part:
                left, right = part.split(op, 1)
                conds.append(Condition(left.strip(), op, right.strip()))
                matched = True
                break
        if not matched:
            raise SyntaxError(f"Invalid condition: {part!r}")
    return conds


# ── Clear Node ────────────────────────────────────────────
@dataclass
class ClearNode:
    pass

# ── Import Node ────────────────────────────────────────────
@dataclass
class ImportNode:
    path: str

# ── Text Node ─────────────────────────────────────────────
@dataclass
class TextNode:
    operations: list   # list of (op_type, args) tuples
    length_source: str   # source for @text:length
    var_create: str      # variable to store length result

# ── Block Chain Node ──────────────────────────────────────
@dataclass
class BlockChainNode:
    """& chained multi-line blocks"""
    blocks: list

# ── Fetch Node ────────────────────────────────────────────
@dataclass
class FetchNode:
    """Universal data pipeline — fetch from $ to"""
    pipes: list   # list of (source, target) tuples

# ── Random Or Node ────────────────────────────────────────
@dataclass
class RandomOrNode:
    options: list   # list of strings to pick from

# ── Multi Statement Node ──────────────────────────────────
@dataclass
class MultiStmtNode:
    """& separated statements — all run in order"""
    statements: list

# ── If Chain Node ─────────────────────────────────────────
@dataclass
class IfChainNode:
    """if / other if / other chain — first match wins"""
    branches: list   # list of (conditions_or_None, body)
    # conditions=None means 'other' (else)

# ── Parser ─────────────────────────────────────────────────

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos    = 0

    def current(self) -> Optional[Token]:
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def consume(self, expected_type: str = None) -> Token:
        tok = self.tokens[self.pos]
        if expected_type and tok.type != expected_type:
            raise SyntaxError(
                f"Line {tok.line}: expected {expected_type}, got {tok.type} ({tok.value!r})"
            )
        self.pos += 1
        return tok

    def parse(self) -> ProgramNode:
        stmts = []
        while self.pos < len(self.tokens):
            stmt = self.parse_stmt()
            if stmt is not None:
                stmts.append(stmt)
        return ProgramNode(statements=stmts)

    def parse_stmt(self) -> Optional[Any]:
        tok = self.current()
        if not tok:
            return None
        if tok.type == IF_COND:
            return self.parse_if_chain()
        if tok.type == FUNC_OPEN:
            return self.parse_func_block()
        if tok.type == INLINE_CALL:
            return self.parse_inline_call()
        if tok.type == ADDFUNC_OPEN:
            return self.parse_addfunc()
        if tok.type == GUI_OPEN:
            return self.parse_gui_block_from_open()
        if tok.type == MULTI_STMT:
            return self.parse_multi_stmt()
        if tok.type == RANDOM_OR:
            return self.parse_random_or()
        if tok.type == FETCH_OPEN:
            return self.parse_fetch()
        if tok.type == TEXT_OPEN:
            return self.parse_text()
        if tok.type == CLEAR_CALL:
            return self.parse_clear()
        if tok.type == IMPORT_CALL:
            return self.parse_import()
        self.pos += 1
        return None

    def parse_clear(self) -> ClearNode:
        self.consume(CLEAR_CALL)
        self._consume_close()
        return ClearNode()

    def parse_import(self) -> ImportNode:
        self.consume(IMPORT_CALL)
        path = None
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type == CONTENT:
                path = tok.value
        chained = self._consume_close(); self._last_was_chain = chained
        return ImportNode(path=path or '')

    def parse_text(self) -> TextNode:
        import re
        self.consume(TEXT_OPEN)
        operations  = []
        length_src  = None
        var_create  = None

        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.current()

            if tok.type == TEXT_LENGTH:
                self.consume()
                length_src = tok.value

            elif tok.type == VAR_CREATE:
                self.consume()
                var_create = tok.value

            elif tok.type == TEXT_LINE:
                self.consume()
                line = tok.value

                # text:maxlength"N"
                m = re.match(r'text:maxlength"(\d+)"', line)
                if m:
                    operations.append(('maxlength', int(m.group(1))))
                    continue

                # text:capital"@var/name/S":N
                m = re.match(r'text:capital"(.+)":(\d+)', line)
                if m:
                    operations.append(('capital', m.group(1), int(m.group(2))))
                    continue

                # text:lower"@var/name/S":N
                m = re.match(r'text:lower"(.+)":(\d+)', line)
                if m:
                    operations.append(('lower', m.group(1), int(m.group(2))))
                    continue
            else:
                self.consume()

        chained = self._consume_close(); self._last_was_chain = chained
        return TextNode(operations=operations, length_source=length_src, var_create=var_create)

    def parse_fetch(self) -> FetchNode:
        import re
        self.consume(FETCH_OPEN)
        pipes = []
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.current()
            if tok.type == FETCH_LINE:
                self.consume()
                # format: +from-$+to-
                m = re.match(r'^[+]?(.+)-[$][+](.+)-$', tok.value)
                if m:
                    pipes.append((m.group(1).strip(), m.group(2).strip()))
            else:
                self.consume()
        chained = self._consume_close(); self._last_was_chain = chained
        return FetchNode(pipes=pipes)

    def parse_random_or(self) -> RandomOrNode:
        tok     = self.consume(RANDOM_OR)
        options = tok.value.split('||')
        return RandomOrNode(options=options)

    def parse_multi_stmt(self) -> MultiStmtNode:
        count_tok = self.consume(MULTI_STMT)
        count     = int(count_tok.value)
        stmts     = []
        for _ in range(count):
            tok = self.current()
            if not tok:
                break
            if tok.type == INLINE_CALL:
                stmts.append(self.parse_inline_call())
            elif tok.type == FUNC_OPEN:
                stmts.append(self.parse_func_block())
            else:
                stmts.append(self.parse_stmt())
        return MultiStmtNode(statements=stmts)

    def _parse_possibly_chained_body(self):
        """Parse a body that might be @-& chained multiple blocks"""
        first = self.parse_stmt()
        # after parse_stmt, check if the last close was @-&
        # We track this via a flag on the parser
        if getattr(self, '_last_was_chain', False):
            blocks = [first]
            while getattr(self, '_last_was_chain', False):
                self._last_was_chain = False
                nxt = self.parse_stmt()
                blocks.append(nxt)
            return BlockChainNode(blocks=blocks)
        return first

    def parse_if_chain(self):
        """Parse if / other if / other as a single chain node"""
        branches = []

        # first branch — the if,
        tok   = self.consume(IF_COND)
        conds = parse_conditions(tok.value)
        body  = self._parse_possibly_chained_body()
        branches.append((conds, body))

        # subsequent branches — other if, / other,
        while self.current() and self.current().type in (OTHER_IF, OTHER):
            tok = self.current()
            if tok.type == OTHER_IF:
                self.consume()
                conds = parse_conditions(tok.value)
                body  = self.parse_stmt()
                branches.append((conds, body))
            elif tok.type == OTHER:
                self.consume()
                body = self.parse_stmt()
                branches.append((None, body))
                break   # other, is always last

        if len(branches) == 1:
            # plain if, no chain — return simple IfNode for compatibility
            conds, body = branches[0]
            return IfNode(conditions=conds, body=body)
        return IfChainNode(branches=branches)

    def parse_if(self) -> IfNode:
        tok   = self.consume(IF_COND)
        conds = parse_conditions(tok.value)
        body  = self.parse_stmt()
        return IfNode(conditions=conds, body=body)

    def parse_inline_call(self) -> InlineCallNode:
        tok            = self.consume(INLINE_CALL)
        depth_str, content = tok.value.split(':', 1)
        return InlineCallNode(depth=int(depth_str), content=content)

    def parse_func_block(self) -> Any:
        tok   = self.consume(FUNC_OPEN)
        funcs = [f.strip() for f in tok.value.split(',')]

        if funcs == ['var']:
            return self.parse_var_block()
        if funcs[0] == 'math' and len(funcs) == 1:
            return self.parse_math_block()
        if funcs[0] == 'math':
            return self.parse_math_var_block(funcs)
        if 'loop' in funcs:
            return self.parse_loop_block(funcs)
        if 'user' in funcs:
            return self.parse_user_block(funcs)
        if 'output' in funcs:
            return self.parse_output_block(funcs)
        if 'dyn' in funcs:
            return self.parse_dyn_block(funcs)
        if 'gui' in funcs:
            return self.parse_gui_block(funcs)
        return self.parse_generic_or_container(funcs)

    # ── @var+ ──
    def parse_var_block(self) -> VarBlockNode:
        variables = []
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type == VAR_DECL:
                name, value = tok.value.split('=', 1)
                variables.append(VarNode(name=name.strip(), value=value.strip()))
        chained = self._consume_close(); self._last_was_chain = chained
        return VarBlockNode(variables=variables)

    # ── @math,var+ (math with extra funcs) ──
    def parse_math_var_block(self, funcs: list) -> MathNode:
        expr_tok = None
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type in (MATH_EXPR, CONTENT):
                expr_tok = tok
        chained = self._consume_close(); self._last_was_chain = chained
        return MathNode(expression=expr_tok.value if expr_tok else '')

    # ── @math+ ──
    def parse_math_block(self) -> MathNode:
        expr_tok = self.consume(MATH_EXPR)
        chained = self._consume_close(); self._last_was_chain = chained
        return MathNode(expression=expr_tok.value)

    # ── @user,... ──
    def parse_user_block(self, funcs: List[str]) -> UserBlockNode:
        prompt     = None
        var_create = None
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type == CONTENT:
                prompt = tok.value
            elif tok.type == VAR_CREATE:
                var_create = tok.value
        chained = self._consume_close(); self._last_was_chain = chained
        return UserBlockNode(funcs=funcs, prompt=prompt, var_create=var_create)

    # ── @loop,... ──
    def parse_loop_block(self, funcs: List[str]) -> LoopNode:
        non_loop   = [f for f in funcs if f != 'loop']
        content    = None
        static_cnt = None
        dyn_conds  = []

        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.current()
            if tok.type == CONTENT:
                self.consume(); content = tok.value
            elif tok.type == LOOP_COUNT:
                self.consume(); static_cnt = int(tok.value)
            elif tok.type == IF_COND:
                self.consume()
                conds = parse_conditions(tok.value)
                if self.current() and self.current().type == LOOP_COUNT:
                    count = int(self.consume().value)
                    dyn_conds.append((conds, count))
            else:
                self.consume()

        chained = self._consume_close(); self._last_was_chain = chained
        return LoopNode(funcs=non_loop, content=content,
                        static_count=static_cnt, dyn_conditions=dyn_conds)

    # ── generic or container ──
    def _is_chain_close(self) -> bool:
        """Check if current token is a chaining close @-&"""
        return self.current() and self.current().type == FUNC_CLOSE_CHAIN

    def _consume_close(self):
        """Consume FUNC_CLOSE, FUNC_CLOSE_CHAIN, or FUNC_CLOSE_END"""
        tok = self.current()
        if tok and tok.type in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            self.pos += 1
            return tok.type == FUNC_CLOSE_CHAIN  # only & continues chain, # ends it
        return False

    def parse_generic_or_container(self, funcs: List[str]) -> Any:
        """
        If the block body contains if+inline-call pairs → ContainerNode
        If the block body is direct content              → GenericNode
        """
        content    = None
        statements = []

        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.current()
            if tok.type == CONTENT:
                self.consume(); content = tok.value
            elif tok.type == IF_COND:
                statements.append(self.parse_if_chain())
            elif tok.type == INLINE_CALL:
                statements.append(self.parse_inline_call())
            elif tok.type == VAR_CREATE:
                self.consume()
                # store as a special node to save random/user output
                from dataclasses import dataclass as _dc
                statements.append(VarCreateNode(name=tok.value))
            else:
                self.consume()

        chained = self._consume_close(); self._last_was_chain = chained

        if statements:
            return ContainerNode(funcs=funcs, statements=statements)
        return GenericNode(funcs=funcs, content=content)


    # ── @gui ──
    def parse_gui_block_from_open(self):
        tok = self.consume(GUI_OPEN)
        funcs = [f.strip() for f in tok.value[1:-1].split(',')]  # strip @ and +
        return self.parse_gui_block(funcs)

    def parse_gui_block(self, funcs: list):
        import re
        title    = 'DAMAGE App'
        width    = 800
        height   = 600
        elements = []
        handlers = []

        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.current()
            if tok is None: break

            if tok.type == GUI_PROP:
                prop = tok.value   # e.g. gui:winname"My App"
                self.consume()

                # winname
                m = re.match(r'gui:winname"(.+)"', prop)
                if m: title = m.group(1); continue

                # winsize
                m = re.match(r'gui:winsize"(\d+):(\d+)"', prop)
                if m: width, height = int(m.group(1)), int(m.group(2)); continue

                # pressable  @gui:pressable"name:BtnName":pos+x,y-
                m = re.match(r'gui:pressable"name:([^"]+)"(?::pos\+([^,]+),([^-]+)-)?', prop)
                if m:
                    px = int(m.group(2)) if m.group(2) else 0
                    py = int(m.group(3)) if m.group(3) else 0
                    elements.append(GuiElement(kind='pressable', content=m.group(1),
                        writable=False, pos=(px,py), elem_id='', name=m.group(1)))
                    continue

                # input (with optional writableelement)
                m = re.match(r'gui:input(:writableelement)?:text\+(.+)-:(\w+)', prop)
                if m:
                    writable = m.group(1) is not None
                    content  = m.group(2)
                    eid      = m.group(3)
                    elements.append(GuiElement(kind='input', content=content,
                        writable=writable, pos=(0,0), elem_id=eid, name=''))
                    continue

                # text label  @gui:text+content-:pos+x,y-
                m = re.match(r'gui:text\+(.+?)-:pos\+([^,]+),([^-]+)-', prop)
                m2 = re.match(r'gui:text\+(.+?)-$', prop) if not m else None
                if m:
                    px, py = int(m.group(2)), int(m.group(3))
                    elements.append(GuiElement(kind='text', content=m.group(1),
                        writable=False, pos=(px,py), elem_id='', name=''))
                    continue
                if m2:
                    elements.append(GuiElement(kind='text', content=m2.group(1),
                        writable=False, pos=(0,0), elem_id='', name=''))
                    continue

            elif tok.type == GUI_WRITE:
                eid, content = tok.value.split(':', 1)
                self.consume()
                elements.append(GuiElement(kind='write', content=content,
                    writable=True, pos=(0,0), elem_id=eid, name=''))
                continue

            elif tok.type == IF_COND:
                cond_tok = self.consume()
                import re as re2
                m = re2.match(r'pressable\+(.+)-:true', cond_tok.value)
                if m:
                    btn_name = m.group(1)
                    self._last_was_chain = False
                    body = self._parse_possibly_chained_body()
                    handlers.append((btn_name, body))
                    # if chain ended with @-# the GUI block is done too
                    if not self._last_was_chain:
                        break
                    continue

            else:
                self.consume()

        chained = self._consume_close(); self._last_was_chain = chained
        return GuiWindowNode(title=title, width=width, height=height,
                             elements=elements, handlers=handlers)

    # ── @dyn ──
    def parse_dyn_block(self, funcs: list):
        assignments = []
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type == DYN_ASSIGN:
                # format: (varname) = value
                if '=' in tok.value:
                    left, right = tok.value.split('=', 1)
                    assignments.append((left.strip(), right.strip()))
        chained = self._consume_close(); self._last_was_chain = chained
        return DynAssignNode(assignments=assignments)

    # ── @output ──
    def parse_output_block(self, funcs: list):
        content  = None
        filename = None
        while self.current() and self.current().type not in (FUNC_CLOSE, FUNC_CLOSE_CHAIN, FUNC_CLOSE_END):
            tok = self.consume()
            if tok.type == CONTENT:
                content = tok.value
            elif tok.type == OUTPUT_NAME:
                filename = tok.value
        chained = self._consume_close(); self._last_was_chain = chained
        return OutputNode(funcs=funcs, content=content, filename=filename)

    # ── @addfunc ──
    def parse_addfunc(self) -> 'AddFuncNode':
        self.consume(ADDFUNC_OPEN)
        body_lines = []
        name = None
        while self.pos < len(self.tokens):
            tok = self.current()
            if tok.type == ADDFUNC_CLOSE:
                self.consume()
                break
            elif tok.type == ADDFUNC_NAME:
                name = tok.value
                self.consume()
            elif tok.type == "ADDFUNC_LINE":
                body_lines.append(tok.value)
                self.consume()
            else:
                self.consume()
        return AddFuncNode(name=name, body="\n".join(body_lines))


# ── helpers ───────────────────────────────────────────────

def parse_source(source: str) -> ProgramNode:
    tokens = tokenize(source)
    return Parser(tokens).parse()

def pretty(node, indent=0):
    pad = "  " * indent
    if isinstance(node, ProgramNode):
        print(f"{pad}Program")
        for s in node.statements: pretty(s, indent+1)
    elif isinstance(node, VarBlockNode):
        print(f"{pad}VarBlock")
        for v in node.variables: print(f"{pad}  {v.name} = {v.value!r}")
    elif isinstance(node, UserBlockNode):
        print(f"{pad}UserBlock(funcs={node.funcs})")
        print(f"{pad}  prompt: {node.prompt!r}")
        print(f"{pad}  save→: {node.var_create!r}")
    elif isinstance(node, ContainerNode):
        print(f"{pad}Container({', '.join(node.funcs)})")
        for s in node.statements: pretty(s, indent+1)
    elif isinstance(node, InlineCallNode):
        print(f"{pad}InlineCall(depth={node.depth}) → {node.content!r}")
    elif isinstance(node, GenericNode):
        print(f"{pad}Call({', '.join(node.funcs)}) → {node.content!r}")
    elif isinstance(node, MathNode):
        print(f"{pad}Math → {node.expression!r}")
    elif isinstance(node, IfNode):
        cond_str = " AND ".join(f"{c.left}{c.op}{c.right}" for c in node.conditions)
        print(f"{pad}If({cond_str})")
        pretty(node.body, indent+1)
    elif isinstance(node, LoopNode):
        print(f"{pad}Loop(funcs={node.funcs}, static={node.static_count})")
        for conds, cnt in node.dyn_conditions:
            cstr = " AND ".join(f"{c.left}{c.op}{c.right}" for c in conds)
            print(f"{pad}  if {cstr} → repeat {cnt}x")
        print(f"{pad}  body: {node.content!r}")
    else:
        print(f"{pad}{node}")


# ── Quick test ─────────────────────────────────────────────
if __name__ == "__main__":
    sample = """
@var+
     x+5-
@-

@user,print,var+
     +What is ((x)) + y = 10. What is Y?-
@var:create+user_input-
@-

@print,var+
if, ((user_input)) > 5
     @+Wrong.-
if, ((user_input)) < 5
     @+Wrong.-
if, ((user_input)) = 5
     @+Correct.-
@-
"""
    ast = parse_source(sample)
    print("── DAMAGE AST ────────────────────────────")
    pretty(ast)


# ── GUI Nodes ─────────────────────────────────────────────
@dataclass
class GuiWindowNode:
    title:    str
    width:    int
    height:   int
    elements: list
    handlers: list   # list of (button_name, action_node)

@dataclass
class GuiElement:
    kind:      str          # text, input, pressable
    content:   str
    writable:  bool
    pos:       tuple        # (x, y)
    elem_id:   str
    name:      str          # for pressable

@dataclass
class GuiWriteNode:
    elem_id: str
    content: str

# ── Dynamic Assignment Node ───────────────────────────────
@dataclass
class DynAssignNode:
    assignments: list   # list of (varname, expr) tuples

# ── Output Node ───────────────────────────────────────────
@dataclass
class OutputNode:
    funcs:    list
    content:  str
    filename: str

# ── User Function Definition Node ─────────────────────────
@dataclass
class AddFuncNode:
    name: str
    body: str   # raw source lines stored as string
